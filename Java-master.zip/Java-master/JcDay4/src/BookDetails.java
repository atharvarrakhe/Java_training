
public class BookDetails {

	/*public static void main(String[] args) {
		Book b1=new Book();
		b1.setTitle("abs");
		b1.setBookId(1);
		b1.setPrice(99);
		b1.setAuthor("saad");
		
		System.out.println(b1.getAuthor()+"  "+b1.getBookId()+"  "+b1.getPrice()+"  "+b1.getTitle());

	}*/

}

class EngineeringBook extends Book{

	public static void main(String[] args) {
		Book b2=new Book();
		
		b2.setTitle("abs");
		b2.setBookId(1);
		b2.setPrice(99);
		b2.setAuthor("saad");
		b2.setCat("sakj");
		b2.toma();
	}
}
