class MyThread<MyRunnable> extends Thread{
MyThread(){}

class MyThread(MyRunnable myRunnable) {
	// TODO Auto-generated constructor stub
}

public class run {
	
	}
