package com.Unext.Opps;

import java.sql.Date;

public class Order {
int orderId;
int CustromerId;
String state;
String city;
int zip;
int totalAmount;
Date OrderDate;
Date deliveryDate;
}
