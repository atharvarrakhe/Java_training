package com.Unext.Opps;

public class OrderIteam {
int orderId;
int productId;
int quantity;

}
