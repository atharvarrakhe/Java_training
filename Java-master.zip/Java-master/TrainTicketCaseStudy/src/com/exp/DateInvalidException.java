package com.exp;

public class DateInvalidException extends Exception {

	 public DateInvalidException(){
		super("Date is invalid");
	}

}
